import cv2
import os
import sys
import numpy as np
import glob
import argparse

#take all images in current folder and convert them to grayscale
def convert_to_gray():
    for infile in glob.glob("*.png"):
        file, ext = os.path.splitext(infile)
        img = cv2.imread(infile)
        gray = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)
        cv2.imwrite(file + "-gray.png", gray)
    
if __name__ == "__main__":
    convert_to_gray()